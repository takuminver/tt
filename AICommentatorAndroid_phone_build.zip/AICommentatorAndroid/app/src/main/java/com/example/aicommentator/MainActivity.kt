package com.example.aicommentator

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var tts: TextToSpeech
    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopCapture() }
    }
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastComment = ""
    private var lastSpokenAt = 0L
    private var running = false
    private var screenWidth = 0
    private var screenHeight = 0
    private var density = 0
    private val labeler by lazy { ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS) }

    private val captureLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            startCapture(result.resultCode, result.data!!)
        } else {
            status.text = "画面共有が許可されませんでした"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        val title = TextView(this).apply {
            text = "AIゲーム実況（試作版）"
            textSize = 24f
        }
        status = TextView(this).apply {
            text = "停止中"
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        val start = Button(this).apply {
            text = "実況を開始"
            setOnClickListener { requestCapture() }
        }
        val stop = Button(this).apply {
            text = "実況を停止"
            setOnClickListener { stopCapture() }
        }
        log = TextView(this).apply { textSize = 14f; text = "実況ログがここに表示されます。" }
        val scroll = ScrollView(this).apply { addView(log) }
        root.addView(title)
        root.addView(status)
        root.addView(start)
        root.addView(stop)
        root.addView(TextView(this).apply {
            text = "使い方：開始を押して画面共有を許可し、その後ゲームに切り替えてください。"
            textSize = 14f
            setPadding(0, 16, 0, 16)
        })
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun requestCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        captureLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        try {
            ContextCompat.startForegroundService(this, Intent(this, ProjectionService::class.java))
            val metrics = resources.displayMetrics
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            density = metrics.densityDpi
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(projectionCallback, handler)
            reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            virtualDisplay = projection?.createVirtualDisplay(
                "AICommentator", screenWidth, screenHeight, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader?.surface, null, handler
            )
            running = true
            status.text = "実況中：ゲーム画面を解析しています"
            handler.post(captureTask)
        } catch (e: Exception) {
            status.text = "開始できませんでした：${e.localizedMessage}"
            stopCapture()
        }
    }

    private val captureTask = object : Runnable {
        override fun run() {
            if (!running) return
            val image = reader?.acquireLatestImage()
            if (image != null) {
                val bitmap = imageToBitmap(image)
                image.close()
                if (bitmap != null) analyze(bitmap)
            }
            handler.postDelayed(this, 5000L)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * screenWidth
            val padded = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride, screenHeight, Bitmap.Config.ARGB_8888
            )
            padded.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(padded, 0, 0, screenWidth, screenHeight)
            padded.recycle()
            Bitmap.createScaledBitmap(cropped, 512, (512f * screenHeight / screenWidth).toInt().coerceAtLeast(1), true)
                .also { cropped.recycle() }
        } catch (_: Exception) { null }
    }

    private fun analyze(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        labeler.process(input)
            .addOnSuccessListener { labels ->
                val top = labels.sortedByDescending { it.confidence }.take(3)
                val names = top.filter { it.confidence >= 0.55f }.map { it.text }
                val description = if (names.isEmpty()) "ゲーム画面に変化がありました" else names.joinToString("、")
                val comment = makeComment(names, description)
                val now = System.currentTimeMillis()
                if (comment != lastComment && (now - lastSpokenAt > 9000L)) {
                    speak(comment)
                    lastComment = comment
                    lastSpokenAt = now
                }
                bitmap.recycle()
            }
            .addOnFailureListener {
                bitmap.recycle()
                status.text = "画像解析に失敗しました"
            }
    }

    // ML Kitの一般画像ラベルを実況文に変換する簡易ルールです。
    // ゲーム専用の状況理解や勝敗判定を保証するものではありません。
    private fun makeComment(names: List<String>, fallback: String): String {
        val joined = names.joinToString(" ").lowercase(Locale.ROOT)
        return when {
            joined.contains("person") || joined.contains("human") ->
                "画面にキャラクターが見えています。ここからどう動くか注目です。"
            joined.contains("vehicle") || joined.contains("car") ->
                "乗り物が見えています。周囲の状況にも注目していきましょう。"
            joined.contains("animal") ->
                "何か生き物が登場しました。ゲームの展開が気になります。"
            joined.contains("text") ->
                "画面に表示が出ています。次の展開を確認しましょう。"
            names.isNotEmpty() ->
                "画面を確認中です。${names.take(2).joinToString("と")}が見えています。"
            else -> "$fallback。次の展開を見ていきましょう。"
        }
    }

    private fun speak(text: String) {
        runOnUiThread {
            log.text = "● $text\n\n" + log.text
            tts.speak(text, TextToSpeech.QUEUE_ADD, null, "comment-${System.currentTimeMillis()}")
        }
    }

    private fun stopCapture() {
        running = false
        handler.removeCallbacks(captureTask)
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        projection?.stop()
        projection = null
        stopService(Intent(this, ProjectionService::class.java))
        if (::status.isInitialized) status.text = "停止中"
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.JAPAN
        }
    }

    override fun onDestroy() {
        stopCapture()
        if (::tts.isInitialized) tts.shutdown()
        labeler.close()
        super.onDestroy()
    }
}
